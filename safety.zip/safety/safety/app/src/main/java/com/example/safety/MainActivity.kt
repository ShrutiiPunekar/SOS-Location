package com.example.safety

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences = getSharedPreferences("WomenSafetyApp", Context.MODE_PRIVATE)

        // Check if phone numbers are already saved
        val phone1 = sharedPreferences.getString("phone1", null)
        val phone2 = sharedPreferences.getString("phone2", null)

        if (!phone1.isNullOrEmpty() && !phone2.isNullOrEmpty()) {
            // If numbers exist, directly open SOS Activity
            startActivity(Intent(this, SosActivity::class.java))
            finish() // Close MainActivity
            return
        }

        // If first time, show phone number entry screen
        setContentView(R.layout.activity_main)

        val phone1Input = findViewById<EditText>(R.id.phone1)
        val phone2Input = findViewById<EditText>(R.id.phone2)
        val saveButton = findViewById<Button>(R.id.saveButton)

        saveButton.setOnClickListener {
            val inputPhone1 = phone1Input.text.toString().trim()
            val inputPhone2 = phone2Input.text.toString().trim()

            if (inputPhone1.isNotEmpty() && inputPhone2.isNotEmpty()) {
                // Save phone numbers
                sharedPreferences.edit()
                    .putString("phone1", inputPhone1)
                    .putString("phone2", inputPhone2)
                    .apply()

                Toast.makeText(this, "Phone numbers saved!", Toast.LENGTH_SHORT).show()

                // Navigate to SOS page
                startActivity(Intent(this, SosActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Please enter both phone numbers", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
