package com.example.safety

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class SosActivity : AppCompatActivity() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var sharedPreferences: SharedPreferences
    private val REQUEST_PERMISSIONS_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sos)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        sharedPreferences = getSharedPreferences("WomenSafetyApp", Context.MODE_PRIVATE)

        val sosButton = findViewById<Button>(R.id.sosButton)
        val messageSpinner = findViewById<Spinner>(R.id.messageSpinner)

        // ✅ Apply custom black text style for spinner items
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.sos_messages, // Messages from strings.xml
            R.layout.spinner_item // Custom layout for black text
        )
        adapter.setDropDownViewResource(R.layout.spinner_item) // Apply for dropdown as well
        messageSpinner.adapter = adapter

        sosButton.setOnClickListener {
            val selectedMessage = messageSpinner.selectedItem.toString()
            if (checkAndRequestPermissions()) {
                sendSOSMessage(selectedMessage)
            }
        }
    }

    private fun checkAndRequestPermissions(): Boolean {
        val permissionsNeeded = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.SEND_SMS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }

        return if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toTypedArray(), REQUEST_PERMISSIONS_CODE)
            false
        } else {
            true
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, "Permissions granted! Now you can send SOS messages.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permissions denied! SMS and Location are required.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun sendSOSMessage(selectedMessage: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS or Location permission denied", Toast.LENGTH_SHORT).show()
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            val phone1 = sharedPreferences.getString("phone1", "")
            val phone2 = sharedPreferences.getString("phone2", "")

            if (!phone1.isNullOrEmpty() && !phone2.isNullOrEmpty() && location != null) {
                val message = "$selectedMessage My Location: https://maps.google.com/?q=${location.latitude},${location.longitude}"
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(phone1, null, message, null, null)
                smsManager.sendTextMessage(phone2, null, message, null, null)
                Toast.makeText(this, "SOS message sent!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to send SOS message", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Unable to fetch location", Toast.LENGTH_SHORT).show()
        }
    }
}
